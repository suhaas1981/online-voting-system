const express = require("express");
const path = require("path");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const connectDB = require("./config/db");
const User = require("./models/User");

const JWT_SECRET = process.env.JWT_SECRET || "your_jwt_secret_here";
const TOKEN_EXPIRES_IN = "24h";

const emailIsValid = (e) => /\S+@\S+\.\S+/.test(String(e || ""));
const extractCleanPhone = (p) => String(p || "").replace(/\D/g, "");

const mkToken = (payload) => jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRES_IN });

const getUserFromReq = async (req) => {
  let token = req.cookies.authToken;
  if (req.headers.authorization && req.headers.authorization.startsWith("Bearer ")) {
    token = req.headers.authorization.split(" ")[1];
  }
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return await User.findById(decoded.id);
  } catch (err) {
    return null;
  }
};

// Connect to MongoDB
connectDB();

const app = express();

// Middleware
app.use(express.json());
app.use(cookieParser());

// Custom auth middleware
const requireAuth = async (req, res, next) => {
  const user = await getUserFromReq(req);
  if (user) {
    req.user = user;
    return next();
  }

  if (req.originalUrl.startsWith('/api/') || req.headers.authorization) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }
  res.redirect('/login');
};

// Role-based authorization middleware
const requireRole = (role) => {
  return (req, res, next) => {
    if (req.user && req.user.role === role) {
      next();
    } else {
      res.status(403).send('Forbidden: You do not have access to this resource.');
    }
  };
};

// --- AUTH API ROUTES ---
app.post("/api/register", async (req, res) => {
  try {
    const { fullName, username, email, phone, birthDate, password, role: requestRole } = req.body || {};

    // basic validation
    if (!fullName || !username || !email || !phone || !birthDate || !password) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }
    if (typeof fullName !== "string" || fullName.trim().length < 2) {
      return res.status(400).json({ success: false, message: "Full name must be at least 2 characters" });
    }
    if (typeof username !== "string" || username.trim().length < 3) {
      return res.status(400).json({ success: false, message: "Username must be at least 3 characters" });
    }
    if (!emailIsValid(email)) {
      return res.status(400).json({ success: false, message: "Email is invalid" });
    }
    const cleanedPhone = extractCleanPhone(phone);
    if (cleanedPhone.length < 6) {
      return res.status(400).json({ success: false, message: "Phone number seems invalid" });
    }
    if (String(password).length < 6) {
      return res.status(400).json({ success: false, message: "Password must be at least 6 characters" });
    }
    const parsedBirth = new Date(birthDate);
    if (Number.isNaN(parsedBirth.getTime())) {
      return res.status(400).json({ success: false, message: "Birth date is invalid" });
    }

    // uniqueness checks
    const existingByEmail = await User.findOne({ email: email.toLowerCase().trim() });
    if (existingByEmail) return res.status(400).json({ success: false, message: "Email already in use" });
    const existingByUsername = await User.findOne({ username: username.trim().toLowerCase() });
    if (existingByUsername) return res.status(400).json({ success: false, message: "Username already taken" });

    // hash + create
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Auto admin rule or fallback
    const role = (username.trim().toLowerCase().startsWith('admin')) ? 'admin' : (['admin', 'user'].includes(requestRole) ? requestRole : 'user');

    const newUser = await User.create({
      fullName: fullName.trim(),
      username: username.trim(),
      email: email.toLowerCase().trim(),
      phone: phone, 
      birthDate: parsedBirth,
      password: hashedPassword,
      role
    });

    const token = mkToken({ id: newUser._id.toString(), role: newUser.role });
    const userToReturn = {
      id: newUser._id.toString(),
      fullName: newUser.fullName,
      username: newUser.username,
      email: newUser.email,
      phone: newUser.phone,
      birthDate: newUser.birthDate,
      role: newUser.role,
      hashedPassword: newUser.password // Added so you can screenshot it in Postman
    };

    res.cookie('authToken', token, { httpOnly: true });
    return res.status(201).json({
      success: true,
      message: "User registered successfully",
      token,
      user: userToReturn
    });
  } catch (err) {
    console.error("registerUser error:", err);
    if (err.code === 11000) {
      const dupKey = Object.keys(err.keyValue || {})[0];
      return res.status(400).json({ success: false, message: `${dupKey} already exists` });
    }
    return res.status(500).json({ success: false, message: "Server error" });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) {
      return res.status(400).json({ success: false, message: "All fields are required." });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    // Safeguard: If this is the "admin" account but it was registered before we added roles, fix it now.
    if (user.username.toLowerCase().startsWith('admin') && user.role !== 'admin') {
      user.role = 'admin';
      await user.save();
    }

    const token = mkToken({ id: user._id.toString(), role: user.role });
    res.cookie('authToken', token, { httpOnly: true });
    
    return res.status(200).json({ 
      success: true, 
      message: "Login successful!",
      token,
      user: { 
        id: user._id.toString(), 
        fullName: user.fullName,
        username: user.username, 
        email: user.email, 
        role: user.role 
      }
    });
  } catch (error) {
    console.error('Login Error:', error);
    return res.status(500).json({ success: false, message: 'Server error.' });
  }
});

app.get("/api/me", async (req, res) => {
  try {
    const user = await getUserFromReq(req);
    if (user) {
      // Streak Logic
      const now = new Date();
      const last = user.lastActiveDate ? new Date(user.lastActiveDate) : null;
      if (!last) {
        user.streakCount = 1;
      } else {
        // Ignore time of day for simple day streak calculation
        const diffTime = Math.abs(now.setHours(0, 0, 0, 0) - last.setHours(0, 0, 0, 0));
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays === 1) {
          user.streakCount += 1;
        } else if (diffDays > 1) {
          user.streakCount = 1;
        }
      }
      user.lastActiveDate = new Date();
      await user.save();

      return res.json({ success: true, username: user.username, streakCount: user.streakCount, studyMinutes: user.studyMinutes });
    }
  } catch (err) {
    console.error(err);
  }
  return res.json({ success: false });
});

app.get("/api/data", async (req, res) => {
  try {
    const user = await getUserFromReq(req);
    if (user) {
      return res.json({ success: true, tasks: user.tasks, notes: user.notes, streakCount: user.streakCount, studyMinutes: user.studyMinutes, summaries: user.summaries });
    }
  } catch (err) { }
  return res.json({ success: false });
});

app.post("/api/stats/study", async (req, res) => {
  try {
    const user = await getUserFromReq(req);
    if (user && req.body.minutes) {
      user.studyMinutes = (user.studyMinutes || 0) + req.body.minutes;
      await user.save();
      return res.json({ success: true });
    }
  } catch (err) { }
  return res.json({ success: false });
});

app.post("/api/tasks", async (req, res) => {
  try {
    const user = await getUserFromReq(req);
    if (user) {
      user.tasks = req.body.tasks;
      await user.save();
      return res.json({ success: true });
    }
  } catch (err) { }
  return res.json({ success: false });
});

app.post("/api/notes", async (req, res) => {
  try {
    const user = await getUserFromReq(req);
    if (user) {
      user.notes = req.body.notes;
      await user.save();
      return res.json({ success: true });
    }
  } catch (err) { }
  return res.json({ success: false });
});

app.post("/api/summaries", async (req, res) => {
  try {
    const user = await getUserFromReq(req);
    if (user && req.body.summaries) {
      user.summaries = req.body.summaries;
      await user.save();
      return res.json({ success: true });
    }
  } catch (err) { }
  return res.json({ success: false });
});

app.post("/api/logout", (req, res) => {
  res.clearCookie('authToken');
  res.json({ success: true });
});

// --- PAGE ROUTES ---
// Login page
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "public/pages/login.html"));
});

// Register page
app.get("/register", (req, res) => {
  res.sendFile(path.join(__dirname, "public/pages/register.html"));
});

// Customer Login page
app.get("/customer-login", (req, res) => {
  res.sendFile(path.join(__dirname, "public/pages/customer-login.html"));
});

// Protected admin page
app.get("/admin", requireAuth, requireRole('admin'), (req, res) => {
  res.sendFile(path.join(__dirname, "private/admin.html"));
});

// --- ADMIN API ROUTES ---
app.get("/api/admin/users", requireAuth, requireRole('admin'), async (req, res) => {
  try {
    const users = await User.find({});
    return res.json({ success: true, users });
  } catch (err) {
    return res.status(500).json({ success: false });
  }
});

app.delete("/api/admin/users/:id", requireAuth, requireRole('admin'), async (req, res) => {
  try {
    if (req.user._id.toString() === req.params.id) {
      return res.status(400).json({ success: false, message: "Cannot delete yourself." });
    }
    await User.findByIdAndDelete(req.params.id);
    return res.json({ success: true });
  } catch (err) {
    return res.status(500).json({ success: false });
  }
});

// Serve static files
app.use(express.static(path.join(__dirname, "public")));

// Default route for SPA fallback
app.use((req, res) => {
  res.sendFile(path.join(__dirname, "public/pages/index.html"));
});

// Start server
app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
