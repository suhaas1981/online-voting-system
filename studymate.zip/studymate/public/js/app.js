function get(id) {
  return document.getElementById(id);
}

function navigateTo(targetId) {
  document.querySelectorAll('.view').forEach(view => {
    view.classList.remove('active-view');
    view.classList.add('hidden');
  });
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('active-nav');
  });

  const target = get(targetId);
  if (target) {
    target.classList.remove('hidden');
    setTimeout(() => target.classList.add('active-view'), 10);
  }

  const navBtn = document.querySelector(`.nav-btn[data-target="${targetId}"]`);
  if (navBtn) navBtn.classList.add('active-nav');
}

/* ==================================
   TASKS & NOTES STATE
================================== */
let globalTasks = [];
let globalNotes = "";
let globalSummaries = [];
let isLoggedIn = false;
let quillEditor = null;
let reminderInterval = null;

/* ==================================
   TASKS & REMINDERS
================================== */
function handleTaskEnter(e) {
  if (e.key === 'Enter') addTask();
}

function handleStickyTask(e) {
  if (e.key === 'Enter') addStickyTask();
}

function addTask() {
  const input = get("taskInput");
  const timeInput = get("taskTime");
  if (!input || !input.value.trim()) return;

  globalTasks.push({
    text: input.value.trim(),
    done: false,
    reminderTime: timeInput ? timeInput.value : ""
  });

  input.value = "";
  if (timeInput) timeInput.value = "";

  const btn = document.querySelector('.input-group button');
  if (btn) {
    btn.style.transform = 'scale(0.95)';
    setTimeout(() => btn.style.transform = '', 150);
  }

  loadTasks();
  syncTasks();
}

function addStickyTask() {
  const input = get("stickyTaskInput");
  if (!input || !input.value.trim()) return;

  globalTasks.push({ text: input.value.trim(), done: false, reminderTime: "" });
  input.value = "";
  loadTasks();
  syncTasks();
}

function loadTasks() {
  const list = get("taskList");
  const emptyState = get("emptyTasks");
  const countBadge = get("taskCount");

  if (!list) return;

  list.innerHTML = "";
  if (globalTasks.length === 0) {
    list.style.display = 'none';
    if (emptyState) emptyState.style.display = 'block';
  } else {
    list.style.display = 'flex';
    if (emptyState) emptyState.style.display = 'none';
  }

  if (countBadge) countBadge.innerText = globalTasks.length;
  let completed = 0;

  globalTasks.forEach((task, index) => {
    if (task.done) completed++;

    const div = document.createElement("div");
    div.className = `task-item ${task.done ? "completed" : ""}`;

    let timeBadge = task.reminderTime ? `<span style="font-size:0.8rem; background:rgba(255,255,255,0.1); padding:2px 8px; border-radius:10px; margin-left:10px; color:var(--accent-purple);">🔔 ${task.reminderTime}</span>` : "";

    div.innerHTML = `
      <div class="task-content">
        <input type="checkbox" class="task-checkbox" ${task.done ? "checked" : ""} onchange="toggleTask(${index})">
        <span class="task-text" onclick="toggleTask(${index})">${task.text}</span>
        ${timeBadge}
      </div>
      <button class="delete-btn" onclick="deleteTask(${index})" title="Delete Task">✕</button>
    `;
    list.appendChild(div);
  });

  updateProgress(completed, globalTasks.length);
}

function toggleTask(index) {
  globalTasks[index].done = !globalTasks[index].done;
  loadTasks();
  syncTasks();
}

function deleteTask(index) {
  globalTasks.splice(index, 1);
  loadTasks();
  syncTasks();
}

async function syncTasks() {
  if (isLoggedIn) {
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tasks: globalTasks })
    });
  }
}

function updateProgress(done, total) {
  const bar = get("progressBar");
  const text = get("progressText");
  if (!bar) return;

  const percent = total ? Math.round((done / total) * 100) : 0;
  bar.style.width = percent + "%";
  if (text) text.innerText = `${percent}% Completed (${done}/${total})`;

  if (percent === 100) {
    bar.style.background = 'linear-gradient(90deg, #10b981, #34d399)';
  } else {
    bar.style.background = 'linear-gradient(90deg, #3b82f6, #60a5fa)';
  }
}

function startReminderLoop() {
  if (reminderInterval) clearInterval(reminderInterval);
  reminderInterval = setInterval(() => {
    let now = new Date();
    let currentHHMM = ("0" + now.getHours()).slice(-2) + ":" + ("0" + now.getMinutes()).slice(-2);

    globalTasks.forEach(task => {
      // Trigger exactly on the minute
      if (task.reminderTime === currentHHMM && !task.done && now.getSeconds() === 0) {
        playNotificationSound();
        // Browser notification if permitted
        if (Notification.permission === "granted") {
          new Notification("StudyMate Reminder", { body: `Time for task: ${task.text}` });
        } else {
          alert(`⏰ Task Reminder: ${task.text}`);
        }
      }
    });
  }, 1000); // Check every second, but trigger on second 0
}

/* ==================================
   RICH TEXT NOTES (Quill)
================================== */
let noteTimeout;
function initNotes() {
  const status = get("saveStatus");
  if (get('editor')) {
    quillEditor = new Quill('#editor', {
      theme: 'snow',
      modules: {
        toolbar: [
          [{ 'header': [1, 2, false] }],
          ['bold', 'italic', 'underline', 'strike'],
          [{ 'list': 'ordered' }, { 'list': 'bullet' }],
          [{ 'color': [] }, { 'background': [] }],
          ['clean']
        ]
      }
    });

    // Auto-save on input
    quillEditor.on('text-change', function (delta, oldDelta, source) {
      if (source === 'user') {
        if (status) {
          status.innerText = "Saving...";
          status.classList.remove('saved');
          status.style.color = 'var(--text-muted)';
        }

        globalNotes = quillEditor.root.innerHTML;

        clearTimeout(noteTimeout);
        noteTimeout = setTimeout(() => {
          syncNotes();
          if (status) {
            status.innerText = "Saved";
            status.classList.add('saved');
            status.style.color = 'var(--accent-green)';
          }
        }, 1000);
      }
    });
  }
}

async function syncNotes() {
  if (isLoggedIn) {
    await fetch('/api/notes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notes: globalNotes })
    });
  }
}

/* ==================================
   POMODORO & LOFI
================================== */
const MODES = { work: 25 * 60, shortBreak: 5 * 60, longBreak: 15 * 60 };
let currentMode = 'work';
let totalTime = MODES.work;
let timeLeft = totalTime;
let timerInterval = null;
let isRunning = false;
let circleLength = 691;
if (window.innerWidth <= 600) circleLength = 565;

function formatTime(seconds) {
  let m = Math.floor(seconds / 60);
  let s = seconds % 60;
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

function updateTimerDisplay() {
  const timerText = get("timerText");
  const timerCircle = get("timerCircle");
  if (!timerText || !timerCircle) return;

  timerText.innerText = formatTime(timeLeft);
  const offset = circleLength - (timeLeft / totalTime) * circleLength;
  timerCircle.style.strokeDashoffset = offset;

  if (timeLeft <= 60 && isRunning) {
    timerCircle.style.stroke = 'var(--danger)';
    timerText.style.color = 'var(--danger)';
  } else {
    if (currentMode === 'work') timerCircle.style.stroke = 'var(--accent-purple)';
    else timerCircle.style.stroke = 'var(--accent-green)';
    timerText.style.color = '#fff';
  }
}

function setTimerMode(mode) {
  if (isRunning) {
    if (!confirm("Timer is running! Are you sure you want to switch modes?")) return;
  }
  document.querySelectorAll('.mode-btn').forEach(btn => btn.classList.remove('active-mode'));
  if (get(`mode-${mode}`)) get(`mode-${mode}`).classList.add('active-mode');

  currentMode = mode;
  totalTime = MODES[mode];
  timeLeft = totalTime;

  if (isRunning) toggleTimer();
  updateTimerDisplay();
}

function toggleTimer() {
  const btn = get("startTimerBtn");
  const navBtn = get("navTimerBtn");

  if (isRunning) {
    clearInterval(timerInterval);
    isRunning = false;
    btn.innerText = "Resume Flow";
    btn.classList.remove('pulse');
    btn.style.background = 'rgba(255,255,255,0.1)';
    if (navBtn) navBtn.classList.remove('timer-active-pulse');
  } else {
    if (timeLeft <= 0) timeLeft = totalTime;
    isRunning = true;
    btn.innerText = "Pause";
    btn.classList.add('pulse');
    btn.style.background = 'linear-gradient(135deg, var(--danger), #f87171)';
    if (navBtn) navBtn.classList.add('timer-active-pulse');

    // Starting a work session? Send study minutes every 60s
    let minCounter = 0;
    timerInterval = setInterval(() => {
      timeLeft--;
      updateTimerDisplay();
      document.title = `(${formatTime(timeLeft)}) StudyMate`;

      if (currentMode === 'work' && isLoggedIn) {
        minCounter++;
        if (minCounter >= 60) {
          minCounter = 0;
          fetch('/api/stats/study', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ minutes: 1 })
          }).then(r => r.json()).then(d => {
            if (d.success && get('focusHours')) {
              get('focusHours').innerText = Math.round((d.studyMinutes / 60) * 10) / 10 + "h";
            }
          });
        }
      }

      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        isRunning = false;
        btn.innerText = "Start Flow";
        btn.style.background = 'linear-gradient(135deg, var(--accent-blue), var(--accent-purple))';
        document.title = "⏰ Time's Up! - StudyMate";
        if (navBtn) navBtn.classList.remove('timer-active-pulse');

        playNotificationSound();
        setTimeout(() => alert("⏰ Time's up! Great job!"), 500);
      }
    }, 1000);
  }
}

function resetTimer() {
  clearInterval(timerInterval);
  isRunning = false;
  timeLeft = totalTime;
  if (get("startTimerBtn")) {
    get("startTimerBtn").innerText = "Start Flow";
    get("startTimerBtn").style.background = 'linear-gradient(135deg, var(--accent-blue), var(--accent-purple))';
  }
  if (get("navTimerBtn")) get("navTimerBtn").classList.remove('timer-active-pulse');
  document.title = "StudyMate Dashboard";
  updateTimerDisplay();
}

function playNotificationSound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.1);
    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.5, ctx.currentTime + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.5);
  } catch (e) { }
}

let lofiPlaying = false;
function toggleLofi() {
  const iframe = get('lofiPlayer');
  const btn = get('lofiBtn');
  if (!iframe || !btn) return;

  if (!lofiPlaying) {
    // Send play command via postMessage
    iframe.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
    btn.innerText = "Pause Beats";
    lofiPlaying = true;
  } else {
    iframe.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
    btn.innerText = "Play Beats";
    lofiPlaying = false;
  }
}

/* ==================================
   LIBRARY
================================== */
function loadLibrary() {
  const books = [
    { title: "Atomic Habits", author: "James Clear", img: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&q=80&w=300" },
    { title: "Deep Work", author: "Cal Newport", img: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=300" },
    { title: "Make It Stick", author: "Peter C. Brown", img: "https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&q=80&w=300" },
    { title: "Flow", author: "Mihaly Csikszentmihalyi", img: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=300" },
    { title: "Limitless", author: "Jim Kwik", img: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&q=80&w=300" }
  ];

  const grid = get('bookGrid');
  if (!grid) return;
  grid.innerHTML = "";

  books.forEach(b => {
    let div = document.createElement('div');
    div.className = 'book-item';
    div.innerHTML = `
      <img src="${b.img}" class="book-img" alt="${b.title}">
      <div class="book-title">${b.title}</div>
      <div class="book-author">${b.author}</div>
      <button class="secondary-btn" style="padding: 5px 10px; font-size:0.85rem;" onclick="window.open('https://www.google.com/search?q=${b.title} book', '_blank')">Find Book</button>
    `;
    grid.appendChild(div);
  });
}

/* ==================================
   REFLECTIONS (Summaries)
================================== */
function loadSummaries() {
  const list = get("reflectionList");
  const emptyState = get("emptyReflections");
  if (!list) return;

  list.innerHTML = "";
  if (globalSummaries.length === 0) {
    list.style.display = 'none';
    if (emptyState) emptyState.style.display = 'block';
  } else {
    list.style.display = 'flex';
    if (emptyState) emptyState.style.display = 'none';
  }

  // Iterate backwards so newest is on top
  for (let i = globalSummaries.length - 1; i >= 0; i--) {
    let s = globalSummaries[i];
    let d = new Date(s.date);
    let dateStr = d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });

    let div = document.createElement("div");
    div.className = "reflection-card slide-up-1";
    div.innerHTML = `
      <div class="reflection-date">📅 ${dateStr}</div>
      <div class="reflection-studied">🎯 Studied: ${s.studied}</div>
      <div class="reflection-moral">💡 Takeaway: ${s.moral}</div>
      <button class="delete-btn reflection-delete" onclick="deleteSummary(${i})" title="Delete Reflection">✕</button>
    `;
    list.appendChild(div);
  }
}

function addSummary() {
  const studyInput = get("studyInput");
  const moralInput = get("moralInput");

  if (!studyInput || !moralInput || !studyInput.value.trim() || !moralInput.value.trim()) {
    alert("Please fill out both what you studied and the moral takeaway!");
    return;
  }

  globalSummaries.push({
    date: new Date().toISOString(),
    studied: studyInput.value.trim(),
    moral: moralInput.value.trim()
  });

  studyInput.value = "";
  moralInput.value = "";

  loadSummaries();
  syncSummaries();
}

function deleteSummary(index) {
  if (confirm("Are you sure you want to delete this reflection?")) {
    globalSummaries.splice(index, 1);
    loadSummaries();
    syncSummaries();
  }
}

async function syncSummaries() {
  if (isLoggedIn) {
    await fetch('/api/summaries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ summaries: globalSummaries })
    });
  }
}

/* ==================================
   AUTH & BOOTSTRAP
================================== */
async function checkLoginState() {
  try {
    const res = await fetch('/api/me');
    const data = await res.json();

    const loginBtn = get('loginBtn');
    const userInfo = get('userInfo');
    const userNameSpan = get('userNameSpan');
    const statsGrid = get('statsGrid');
    const stickyTaskBar = get('stickyTaskBar');

    if (data.success) {
      isLoggedIn = true;
      if (loginBtn) loginBtn.style.display = 'none';
      if (userNameSpan) userNameSpan.textContent = data.username;
      if (userInfo) userInfo.style.display = 'flex';

      if (statsGrid) {
        statsGrid.style.display = 'grid';
        if (get('streakFire')) get('streakFire').innerText = `${data.streakCount} 🔥`;
        if (get('focusHours') && data.studyMinutes !== undefined) {
          get('focusHours').innerText = Math.round((data.studyMinutes / 60) * 10) / 10 + "h";
        }
      }
      if (stickyTaskBar) stickyTaskBar.style.display = 'flex';

      // Load remote data
      const dataRes = await fetch('/api/data');
      const dataJson = await dataRes.json();
      if (dataJson.success) {
        globalTasks = dataJson.tasks || [];
        globalNotes = dataJson.notes || "";
        globalSummaries = dataJson.summaries || [];
      }
    } else {
      isLoggedIn = false;
      if (loginBtn) loginBtn.style.display = 'inline-block';
      if (userInfo) userInfo.style.display = 'none';
      if (statsGrid) statsGrid.style.display = 'none';
      if (stickyTaskBar) stickyTaskBar.style.display = 'none';

      globalTasks = [];
      globalNotes = "";
      globalSummaries = [];
    }

    // Draw
    loadTasks();
    loadSummaries();
    if (quillEditor) {
      // Prevent triggering note save randomly on bootstrap
      setTimeout(() => {
        quillEditor.root.innerHTML = globalNotes;
      }, 100);
    }

  } catch (err) { }
}

async function logout() {
  await fetch('/api/logout', { method: 'POST' });
  window.location.reload();
}

document.addEventListener("DOMContentLoaded", async () => {
  if (Notification && Notification.permission !== "granted" && Notification.permission !== "denied") {
    Notification.requestPermission();
  }

  const quotes = [
    "Stay focused and never give up 🚀",
    "Success = Consistency + Hard Work 💪",
    "Small steps every day 🧠",
    "Focus on being productive instead of busy 🎯"
  ];
  if (get("quote")) get("quote").innerText = quotes[Math.floor(Math.random() * quotes.length)];

  initNotes(); // Initialize rich text UI instantly
  loadLibrary(); // Populate library grid immediately

  await checkLoginState();

  updateTimerDisplay();
  startReminderLoop();

  window.addEventListener('resize', () => {
    circleLength = window.innerWidth <= 600 ? 565 : 691;
    updateTimerDisplay();
  });
});