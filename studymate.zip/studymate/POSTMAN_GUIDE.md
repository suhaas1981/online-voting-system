# Postman Testing Guide for StudyMate API

This guide explains how to test the StudyMate API securely using JSON Web Tokens (JWT) through Postman.

## 1. Register a New User

To create an account:
1. Open Postman and open a new tab.
2. Change the method from `GET` to `POST`.
3. Enter URL: `http://localhost:3000/api/register`
4. Go to the **Body** tab below the URL.
5. Select **raw** and change the format dropdown (typically reads "Text") to **JSON**.
6. Paste the following JSON payload:
   ```json
   {
       "fullName": "Test User",
       "username": "testuser",
       "email": "test@example.com",
       "phone": "1234567890",
       "birthDate": "2000-01-01",
       "password": "mypassword"
   }
   ```
7. Click **Send**. You should receive a success message.

## 2. Login to Get Your JWT Token

To authenticate and retrieve your security token:
1. Open a new Postman tab.
2. Change the method to `POST`.
3. Enter URL: `http://localhost:3000/api/login`
4. Go to the **Body** tab, select **raw** -> **JSON**.
5. Paste the payload:
   ```json
   {
       "username": "testuser",
       "password": "mypassword"
   }
   ```
6. Click **Send**.
7. In the response, you will see a `token` field. **Copy the token string** (without quotes).

*(Note: The server also automatically set this token in an HTTP-Only cookie, allowing the frontend browser UI to use it natively!)*

## 3. Accessing Protected Routes

Now you can test any protected route by securely passing the Token in the HTTP Headers. 
For example, let's access the `/api/data` route:

1. Open a new Postman tab.
2. Leave method as `GET`.
3. Enter URL: `http://localhost:3000/api/data`
4. Go to the **Authorization** tab.
5. In the **Type** dropdown, select **Bearer Token**.
6. In the **Token** field that appears on the right, paste the token you copied from Step 2.
7. Click **Send**. 

You will now receive the requested user data exactly as if your frontend browser application had requested it securely!

**Other endpoints you can test securely (using Bearer Token):**
- `GET /api/me`
- `POST /api/tasks` (with body fields)
- `POST /api/notes` (with body fields)
- `GET /api/admin/users` (will only work if your username begins with 'admin')
