const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  fullName: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String },
  birthDate: { type: String },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  tasks: [{ text: String, done: Boolean, reminderTime: String }],
  notes: { type: String, default: "" },
  streakCount: { type: Number, default: 0 },
  lastActiveDate: { type: Date },
  studyMinutes: { type: Number, default: 0 },
  summaries: [{
    date: { type: Date, default: Date.now },
    studied: String,
    moral: String
  }]
});

const User = mongoose.model('User', userSchema);
module.exports = User;
